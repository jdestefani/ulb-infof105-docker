#include <iostream>

extern "C" int trace(int[], unsigned int);

int main() {
  unsigned int n;
  
  std::cout << "Entrer la taille de la matrice carree:";
  std::cin >> n;
  int* M = new int[n*n];
 
  for (unsigned int i=0; i<n; ++i){
	for(unsigned int j=0; j<n; ++j){
	  M[i*n+j] = (i*n+j);
	  std::cout << M[i*n+j] << "\t";
	}
	std::cout << std::endl;
  }
  
  std::cout << "Trace: " << trace(M, n) << std::endl;

  return 0;
}
